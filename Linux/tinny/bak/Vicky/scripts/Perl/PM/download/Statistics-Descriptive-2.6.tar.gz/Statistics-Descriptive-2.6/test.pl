
use Test::Harness;

runtests( 'descr.t' );
